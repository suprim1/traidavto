<div class="container">
    <div class="col-lg-12 col-md-12 col-sm-12 hidden-xs b2-text-zagolovok text-center">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            ПРОСТО
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            ДОРОГО
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            БЫСТРО
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b2-text-v-ramke b2-bg-1 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Не надо никуда ездить просто
                        заполните форму и загрузите фотографии.
                    </td>
                </table>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b2-text-v-ramke b2-bg-2 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Предложим высокую цену, владельцу автомобиля.
                    </td>
                </table>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b2-text-v-ramke b2-bg-3 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Весь процесс оформления
                        документов занимает не более 1-го часа.
                    </td>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 hidden-xs b2-text-zagolovok text-center">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            ЗАКОННО
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            ДЕНЬГИ
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
            ЭВАКУАЦИЯ
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 b2-text-v-ramke b2-bg-4 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Мы гарантируем юридическую
                        чистоту сделки.
                    </td>
                </table>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b2-text-v-ramke b2-bg-5 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Выплачиваем сумму наличными на месте.
                    </td>
                </table>
            </div>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 b2-vertical-align">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b2-text-v-ramke b2-bg-6 b2-bg-cover">
                <table class="b2-table">
                    <td class="b2-bg-wite">
                        Если автомобиль не на ходу, эту часть работы мы берем на себя.
                    </td>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center b2-text-center">
        Если ваш авто попал в ДТП и Вы решили от него избавиться у Вас будет несколько вариантов решения:
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center b2-text-color">
            <table class="b2-margin-15px">
                <tr class="b2-block">
                    <td class="b2-td-bottom">
                        Вы можете самостоятельно разобрать свой автомобиль на запчасти и начать продавать
                    </td>
                </tr>
                <tr>
                    <td class="b2-bledniy">
                        Но тогда вы самостоятельно занимаетесь поиском покупателей, берете на себя оформление документов, правильное хранение б/у запчастей.
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center b2-text-color">
            <table class="b2-margin-15px">
                <tr class="b2-block">
                    <td class="b2-td-bottom">
                        Вы можете продать свой автомобиль после аварии перекупщикам и прогадать в стоимости
                    </td>
                </tr>
                <tr>
                    <td class="b2-bledniy">
                        Мы предложим лучшую цену если вы владелец авто.
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center b2-text-color">
            <table class="b2-margin-15px">
                <tr class="b2-block">
                    <td class="b2-td-bottom">
                        Отремонтировать автомобиль после ДТП и попытаться продать его
                    </td>
                </tr>
                <tr>
                    <td class="b2-bledniy">
                        Здесь вы автоматически теряете в стоимости автомобиля, так как покупатели опасаются битых машин.
                    </td>
                </tr>
            </table>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center b2-text-color">
            <table class="b2-margin-15px">
                <tr class="b2-block">
                    <td class="b2-td-bottom">
                        Сдать разбитую машину на утилизацию
                    </td>
                </tr>
                <tr>
                    <td class="b2-bledniy">
                        Вам придется собрать большое количество документов, Вы получите на руки сертификат а не деньги за машину сразу, эвакуатор станет Вашей заботой.
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>