<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

app\modules\traidavto\TraidavtoAsset::register($this);
$this->title = 'СРОЧНЫЙ ВЫКУП АВТОМОБИЛЕЙ';
?>

<?= $block1  ?>
<?= $blockForm  ?>
<?= $block2  ?>
