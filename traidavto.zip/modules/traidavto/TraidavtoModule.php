<?php

namespace app\modules\traidavto;

use yii\base\Module;

class TraidavtoModule extends Module
{

}
