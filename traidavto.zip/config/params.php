<?php

return [
    'adminEmail' => 'suprim1@yandex.ru',
    'telephone' => '+7 (908) 245-46-50',
];
