<?php

namespace app\widgets\headerfooter;

class HeaderfooterWidget extends \yii\base\Widget {

    public function run() {

        return $this->render('headerfooter');
    }

}
