<div class="container">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 b-header">
        <div class="col-lg-2 col-md-2 col-sm-2 hidden-xs">
            <img src="<?= app\modules\traidavto\TraidavtoAsset::assetUrl() ?>/img/logo.png" class="header-logo">
        </div>
        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 text-center">
            <span class="header-text-top">СРОЧНЫЙ ВЫКУП АВТОМОБИЛЕЙ</span><br>
            <span class="header-text-buttom"> В ПЕРМИ И ПЕРМСКОМ КРАЕ</span>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 hidden-xs text-right header-telephone">
            <div class="col-lg-12">
                <?= Yii::$app->params['telephone'] ?>
            </div>
            <div class="col-lg-12">
                +7 (919) 466-58-38
            </div>
            <div class="col-lg-12">
                +7 (342) 286-86-17
            </div>
        </div>
    </div>
</div>